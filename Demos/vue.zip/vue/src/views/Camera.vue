<template>
  <v-container>
    <v-row justify="center" align="center">
      <v-col cols="12">
        <iframe width="1280" height="720" src="https://www.youtube.com/embed/JBwMDfMfSNU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
export default {

}
</script>

<style>

</style>